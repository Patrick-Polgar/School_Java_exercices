package singleton;

public class Main {

	public static void main(String[] args) {
		Singleton s=Singleton.getSingleton();
		Singleton s1=Singleton.getSingleton();
		

	}

}
